# astrbot_plugin_electric_query — 宿舍电费查询

宿舍电费/剩余电量查询 AstrBot 插件（山东文化产业职业学院校园一卡通 `card.sdcivc.edu.cn`）。

**设计原则**：只读查询 + 定时提醒。不需要账号密码、不需要 token、不需要登录、
不涉及任何支付；充值只给官方入口链接，支付由用户在微信手动完成。

## 接口（公开，2026-09-14 实测有效，无需登录）

网关基址：`https://card.sdcivc.edu.cn/bc/gateway`

```
POST {base}/ecu/api/roomInfo/query/1   body {"loudongId": null}    → 楼栋列表
POST {base}/ecu/api/roomInfo/query/2   body {"loudongId": 楼栋id}   → 房间表具列表
```

房间条目：`{loudong, loudongId, room("2-319照明"), roomId, allAmp, usedAmp}`，
**剩余电量 = allAmp − usedAmp（度）**。同一房间有 照明 / 空调 / 水表 三块表。

## 功能

| 功能 | 说明 | 指令 |
|---|---|---|
| 电量查询 | 实时剩余电量（照明/空调分表） | `电费`、`电费 319`、`电费 2-319` |
| 用法说明 | 查询示例 | `电费帮助` |
| 自动监控 | 每 6 小时（可配）自动查询 | 无需指令 |
| 分级提醒 | `<20度` 普通提醒 ⚠️；`<10度` 强提醒 🚨（附充值入口） | 自动推送 |

缓存：默认 300 秒内重复查询不发起网络请求。
异常处理：网络失败自动重试 2 次、查询超时、接口返回为空/结构变更、楼栋或房间
不存在，均有明确中文提示，不会让插件崩溃。

## 安装

1. 在 AstrBot WebUI「插件管理」导入 `electric_query.zip`（或把文件夹放进 `plugins/`）。
2. 安装依赖：`pip install aiohttp apscheduler`（aiohttp 为 AstrBot 自带，重点是 apscheduler）。
3. 重载插件即可使用（默认配置即可用）。需要调整时优先用 **WebUI 配置**（见下）。

## 配置（WebUI 可视化配置，推荐）

插件已内置 `_conf_schema.json`，在 AstrBot WebUI「插件管理 → electric_query → 配置」
中直接可视化修改，开关、数值、文本都有对应控件，改完保存即生效（重载插件后应用）：

| 配置项 | 类型 | 默认 | 说明 |
|---|---|---|---|
| `building` | 文本 | `2号公寓` | 默认楼栋（支持 2 / 2号楼 / 2号公寓） |
| `room` | 文本 | `319` | 默认房间号 |
| `cache_ttl` | 数字 | `300` | 查询结果缓存秒数 |
| `timeout` | 数字 | `15` | 请求超时（秒） |
| `retries` | 数字 | `2` | 请求失败重试次数 |
| `check_enabled` | 开关 | 开 | 定时低电量监控总开关 |
| `check_interval_hours` | 数字 | `6` | 自动检查间隔（小时），24=每天一次 |
| `warn_threshold` | 数字 | `20` | 普通提醒阈值（度）⚠️ |
| `alert_threshold` | 数字 | `10` | 强提醒阈值（度）🚨 |
| `warn_repeat_hours` | 数字 | `24` | 普通提醒重复间隔（小时） |
| `alert_repeat_hours` | 数字 | `6` | 强提醒重复间隔（小时） |
| `recharge_url` | 文本 | 官方充值页 | 提醒附带的充值入口链接 |

> 说明：插件目录里的 `config.json` 仍作为初始默认值保留；一旦在 WebUI 修改过，
> 以 AstrBot 数据目录 `data/config/electric_query_config.json` 中的值为准（WebUI 优先）。

### config.json（仅初始默认值，字段同上表）

```json
{
    "building": "2号公寓",
    "room": "319",
    "meter_types": ["照明", "空调"],
    "query_url": "https://card.sdcivc.edu.cn/bc/gateway",
    "cache_ttl": 300,
    "timeout": 15,
    "retries": 2,
    "check_enabled": true,
    "check_interval_hours": 6,
    "warn_threshold": 20.0,
    "alert_threshold": 10.0,
    "warn_repeat_hours": 24,
    "alert_repeat_hours": 6,
    "watch_rooms": [],
    "notify_sessions": [],
    "recharge_url": "https://card.sdcivc.edu.cn/#/pages/home/sdwhcyxy-card/electronic-pay"
}
```

`meter_types`（展示的表具类型，`[]`=全部）、`watch_rooms`（额外监控房间）、
`notify_sessions`（推送目标，留空=自动记住使用过指令的会话）这三个列表字段
暂不在 WebUI 展示，需要时直接改 `config.json`。

## 使用示例

```
用户：电费
机器人：🏠 宿舍查询结果

        💡 2-319照明：6.06 度
        ❄️ 2-319空调：1.20 度

        📅 查询时间：2026-09-14 18:00

用户：电费 2-319
用户：电量 5-206
```

低电量提醒示例（自动推送）：

```
🚨 电量严重不足，请立即充值！

🏠 2号公寓 319
💡 2-319照明：6.06 度
❄️ 2-319空调：1.20 度
剩余仅 1.20 度（低于 10 度强提醒线）

👉 充值入口：https://card.sdcivc.edu.cn/#/pages/home/sdwhcyxy-card/electronic-pay
（微信打开后选楼栋→选房间→选金额，支付请手动确认）
📅 2026-09-14 18:00
```

## 常见问题

- **提示「查询结果为空」**：房间号写错，或该房间只有水表而被 `meter_types` 过滤。
- **收不到自动提醒**：先发一次 `电费` 让插件记住会话，或在 `notify_sessions`
  里显式填写会话 ID（形如 `aiocqhttp:GroupMessage:123456789`）。
- **接口变更排查**：Chrome 打开一卡通 → F12 → Network → Fetch/XHR，重放上述
  两个请求对比 URL/参数/响应即可定位变化。
